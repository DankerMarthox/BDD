Integrantes:
	Ian Pérez 		201773549-K
	José Miguel Quezada 	201773528-7
	Martín Salinas		201773557-0

Requerimientos:
	Python 3
	sqlalchemy
	pandas
	numpy
	Oracle
	Base de datos creada y vacía
	Usuario con permisos para crear vistas y triggers
	Nintendo.csv y Sansanoplay.csv en el mismo directorio que script

Instrucciones:
	- Descomprimir zip
	- Abrir cmd o similar
	- Ejecutar python3 BD1.py desde carpeta contenedora de script


* Script hecho en Windows
